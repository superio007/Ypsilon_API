<availresponse xmlns:shared="http://ypsilon.net/shared" cnttarifs="16" offset="0">
  <fares>
    <fare fareid="203915656" shared:faretype="PUB" class="Q" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">QSBLAO</farebase>
        <farebase shared:pax="CHD">QSBLAO</farebase>
        <farebase shared:pax="INF">QSBLAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915627" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaurandc" dfcagent="gaurandcx">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915662" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915657" shared:faretype="CPN" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" corporatecode="QFV11" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">SBLAOUQV</farebase>
        <farebase shared:pax="CHD">SBLAOUQV</farebase>
        <farebase shared:pax="INF">SBLAOUQV</farebase>
      </farebases>
    </fare>
    <fare fareid="203915634" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915635" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915666" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">QIQW</farebase>
        <farebase shared:pax="CHD">QIQW</farebase>
        <farebase shared:pax="INF">QIQW</farebase>
      </farebases>
    </fare>
    <fare fareid="203915636" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SBLAO</farebase>
        <farebase shared:pax="CHD">SBLAO</farebase>
        <farebase shared:pax="INF">SBLAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915667" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">QIQW</farebase>
        <farebase shared:pax="CHD">QIQW</farebase>
        <farebase shared:pax="INF">QIQW</farebase>
      </farebases>
    </fare>
    <fare fareid="203915637" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SBLAO</farebase>
        <farebase shared:pax="CHD">SBLAO</farebase>
        <farebase shared:pax="INF">SBLAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915638" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SBLAO</farebase>
        <farebase shared:pax="CHD">SBLAO</farebase>
        <farebase shared:pax="INF">SBLAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915639" shared:faretype="PUB" class="S" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SBLAO</farebase>
        <farebase shared:pax="CHD">SBLAO</farebase>
        <farebase shared:pax="INF">SBLAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915668" shared:faretype="PUB" class="N" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">QIQW</farebase>
        <farebase shared:pax="CHD">QIQW</farebase>
        <farebase shared:pax="INF">QIQW</farebase>
      </farebases>
    </fare>
    <fare fareid="203915640" shared:faretype="PUB" class="K" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915641" shared:faretype="PUB" class="K" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915643" shared:faretype="PUB" class="K" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915642" shared:faretype="PUB" class="K" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915663" shared:faretype="PUB" class="H" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">HVAAO</farebase>
        <farebase shared:pax="CHD">HVAAO</farebase>
        <farebase shared:pax="INF">HVAAO</farebase>
      </farebases>
    </fare>
    <fare fareid="203915658" shared:faretype="CPN" class="H" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" corporatecode="QFV11" dfcconso="gaura" dfcagent="gaura">
      <farebases>
        <farebase shared:pax="ADT">HBLAOUQV</farebase>
        <farebase shared:pax="CHD">HBLAOUQV</farebase>
        <farebase shared:pax="INF">HBLAOUQV</farebase>
      </farebases>
    </fare>
    <fare fareid="203915644" shared:faretype="PUB" class="K" depapt="MEL" dstapt="DEL" paxtype="ADT" shared:vcr="QF" cos="E" yyfare="false" tickettimelimit="2025-01-02" date="2025-02-12" dfcconso="gauraina" dfcagent="gauraina">
      <farebases>
        <farebase shared:pax="ADT">SVAAO</farebase>
        <farebase shared:pax="CHD">SVAAO</farebase>
        <farebase shared:pax="INF">SVAAO</farebase>
      </farebases>
    </fare>
  </fares>
  <tarifs shared:currency="AUD">
    <tarif tarifid="203915656" adtbuy="676.0" adtsell="736.0" chdbuy="676.0" chdsell="736.0" infbuy="676.0" infsell="736.0" adttax="147.74" chdtax="147.74" inftax="147.74" refundable="false" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="ECSL,ECSL,ECSL">
      <farexrefs>
        <farexref fareid="203915656">
          <flights>
            <flight flightid="1257802989" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161218" legid="1491340537" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161219" legid="1491340538" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161220" legid="1491340539" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802990" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161221" legid="1491340540" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161222" legid="1491340541" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161223" legid="1491340542" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802991" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161224" legid="1491340543" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161225" legid="1491340544" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161226" legid="1491340545" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802992" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161227" legid="1491340546" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161228" legid="1491340547" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161229" legid="1491340548" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802993" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161230" legid="1491340549" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161231" legid="1491340550" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161232" legid="1491340551" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802994" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161233" legid="1491340552" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161234" legid="1491340553" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161235" legid="1491340554" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802995" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161236" legid="1491340555" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161237" legid="1491340556" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161238" legid="1491340557" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802996" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161239" legid="1491340558" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161240" legid="1491340559" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161241" legid="1491340560" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802997" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161242" legid="1491340561" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161243" legid="1491340562" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161244" legid="1491340563" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802998" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161245" legid="1491340564" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161246" legid="1491340565" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161247" legid="1491340566" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802999" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161248" legid="1491340567" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161249" legid="1491340568" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161250" legid="1491340569" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803000" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161251" legid="1491340570" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161252" legid="1491340571" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161253" legid="1491340572" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803001" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161254" legid="1491340573" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161255" legid="1491340574" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161256" legid="1491340575" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803002" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161257" legid="1491340576" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161258" legid="1491340577" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
                <legxref legxrefid="225536161259" legid="1491340578" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="QSBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915627" adtbuy="845.0" adtsell="905.0" chdbuy="845.0" chdsell="905.0" infbuy="845.0" infsell="845.0" adttax="115.39" chdtax="115.39" inftax="115.39" origin="MASTERPRICER-NDC" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915627">
          <flights>
            <flight flightid="1257802737" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536160950" legid="1491339969" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO">
                <legxref legxrefid="225536160951" legid="1491339970" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO">
              </legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915662" adtbuy="845.0" adtsell="905.0" chdbuy="845.0" chdsell="905.0" infbuy="845.0" infsell="905.0" adttax="115.39" chdtax="115.39" inftax="115.39" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="ECSV,ECSV">
      <farexrefs>
        <farexref fareid="203915662">
          <flights>
            <flight flightid="1257803073" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161670" legid="1491340942" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161671" legid="1491340943" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803074" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161672" legid="1491340944" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161673" legid="1491340945" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915657" adtbuy="877.0" adtsell="937.0" chdbuy="877.0" chdsell="937.0" infbuy="877.0" infsell="937.0" adttax="147.74" chdtax="147.74" inftax="147.74" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="ECSV,ECSV,ECSV">
      <farexrefs>
        <farexref fareid="203915657">
          <flights>
            <flight flightid="1257803003" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161260" legid="1491340579" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161261" legid="1491340580" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161262" legid="1491340581" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803004" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161263" legid="1491340582" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161264" legid="1491340583" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161265" legid="1491340584" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803005" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161266" legid="1491340585" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161267" legid="1491340586" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161268" legid="1491340587" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803006" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161269" legid="1491340588" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161270" legid="1491340589" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161271" legid="1491340590" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803007" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161272" legid="1491340591" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161273" legid="1491340592" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161274" legid="1491340593" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803008" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161275" legid="1491340594" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161276" legid="1491340595" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161277" legid="1491340596" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803009" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161278" legid="1491340597" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161279" legid="1491340598" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161280" legid="1491340599" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803010" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161281" legid="1491340600" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161282" legid="1491340601" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161283" legid="1491340602" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803011" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161284" legid="1491340603" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161285" legid="1491340604" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161286" legid="1491340605" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803012" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161287" legid="1491340606" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161288" legid="1491340607" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161289" legid="1491340608" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803013" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161290" legid="1491340609" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161292" legid="1491340610" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161293" legid="1491340611" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803014" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161294" legid="1491340612" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161296" legid="1491340613" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161299" legid="1491340614" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803015" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161301" legid="1491340615" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161303" legid="1491340616" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161305" legid="1491340617" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803016" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161307" legid="1491340618" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161309" legid="1491340619" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
                <legxref legxrefid="225536161311" legid="1491340620" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915634" adtbuy="842.72" adtsell="992.72" chdbuy="842.72" chdsell="992.72" infbuy="842.72" infsell="842.72" adttax="155.23" chdtax="155.23" inftax="155.23" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915634">
          <flights>
            <flight flightid="1257802750" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161118" legid="1491339983" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161119" legid="1491339984" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915635" adtbuy="842.72" adtsell="992.72" chdbuy="842.72" chdsell="992.72" infbuy="842.72" infsell="842.72" adttax="155.23" chdtax="155.23" inftax="155.23" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915635">
          <flights>
            <flight flightid="1257802751" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161120" legid="1491339985" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161121" legid="1491339986" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915666" adtbuy="1039.0" adtsell="1099.0" chdbuy="1039.0" chdsell="1099.0" infbuy="1039.0" infsell="1099.0" adttax="158.44" chdtax="158.44" inftax="158.44" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="EDEAL,ECSV,ECSV">
      <farexrefs>
        <farexref fareid="203915666">
          <flights>
            <flight flightid="1257803081" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161686" legid="1491340958" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161687" legid="1491340959" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161688" legid="1491340960" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803082" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161689" legid="1491340961" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161690" legid="1491340962" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161691" legid="1491340963" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803083" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161692" legid="1491340964" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161693" legid="1491340965" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161694" legid="1491340966" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803084" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161695" legid="1491340967" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161696" legid="1491340968" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161697" legid="1491340969" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803085" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161698" legid="1491340970" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161699" legid="1491340971" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161700" legid="1491340972" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915636" adtbuy="920.54" adtsell="1070.54" chdbuy="920.54" chdsell="1070.54" infbuy="920.54" infsell="920.54" adttax="207.67" chdtax="207.67" inftax="207.67" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915636">
          <flights>
            <flight flightid="1257802752" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161122" legid="1491339987" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161123" legid="1491339988" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161124" legid="1491339989" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802753" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161125" legid="1491339990" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161126" legid="1491339991" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161127" legid="1491339992" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802754" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161128" legid="1491339993" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161129" legid="1491339994" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161130" legid="1491339995" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802755" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161131" legid="1491339996" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161132" legid="1491339997" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161133" legid="1491339998" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802756" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161134" legid="1491339999" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161135" legid="1491340000" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161136" legid="1491340001" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802757" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161137" legid="1491340002" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161138" legid="1491340003" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161139" legid="1491340004" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802758" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161140" legid="1491340005" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161141" legid="1491340006" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161142" legid="1491340007" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802759" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161143" legid="1491340008" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161144" legid="1491340009" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161145" legid="1491340010" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802760" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161146" legid="1491340011" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161147" legid="1491340012" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161148" legid="1491340013" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802761" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161149" legid="1491340014" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161150" legid="1491340015" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161151" legid="1491340016" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802762" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161152" legid="1491340017" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161153" legid="1491340018" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161154" legid="1491340019" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802763" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161155" legid="1491340020" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161156" legid="1491340021" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161157" legid="1491340022" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802764" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161158" legid="1491340023" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161159" legid="1491340024" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161160" legid="1491340025" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802765" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161161" legid="1491340026" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161162" legid="1491340027" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161163" legid="1491340028" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802766" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161164" legid="1491340029" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161165" legid="1491340030" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161166" legid="1491340031" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802767" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161167" legid="1491340032" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161168" legid="1491340033" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161169" legid="1491340034" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802768" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161170" legid="1491340035" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161171" legid="1491340036" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161172" legid="1491340037" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802769" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161173" legid="1491340038" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161174" legid="1491340039" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161175" legid="1491340040" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802770" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161176" legid="1491340041" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161177" legid="1491340042" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161178" legid="1491340043" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802771" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161179" legid="1491340044" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161180" legid="1491340045" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161181" legid="1491340046" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802772" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161182" legid="1491340047" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161183" legid="1491340048" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161184" legid="1491340049" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802773" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161185" legid="1491340050" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161186" legid="1491340051" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161187" legid="1491340052" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802774" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161188" legid="1491340053" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161189" legid="1491340054" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161190" legid="1491340055" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802775" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161191" legid="1491340056" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161192" legid="1491340057" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161193" legid="1491340058" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802776" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161194" legid="1491340059" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161195" legid="1491340060" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161196" legid="1491340061" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802777" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161197" legid="1491340062" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161198" legid="1491340063" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161199" legid="1491340064" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802778" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161200" legid="1491340065" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161201" legid="1491340066" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161202" legid="1491340067" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802779" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161203" legid="1491340068" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161204" legid="1491340069" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161205" legid="1491340070" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802780" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161206" legid="1491340071" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161207" legid="1491340072" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161208" legid="1491340073" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802781" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161209" legid="1491340074" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161210" legid="1491340075" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161211" legid="1491340076" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802782" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161212" legid="1491340077" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161213" legid="1491340078" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161214" legid="1491340079" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802783" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161215" legid="1491340080" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161216" legid="1491340081" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161217" legid="1491340082" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802784" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161291" legid="1491340083" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161295" legid="1491340084" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161297" legid="1491340085" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802785" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161298" legid="1491340086" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161300" legid="1491340087" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161302" legid="1491340088" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802786" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161304" legid="1491340089" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161306" legid="1491340090" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161308" legid="1491340091" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802787" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161310" legid="1491340092" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161312" legid="1491340093" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161314" legid="1491340094" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802788" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161316" legid="1491340095" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161317" legid="1491340096" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161318" legid="1491340097" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802789" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161319" legid="1491340098" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161321" legid="1491340099" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161323" legid="1491340100" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802790" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161325" legid="1491340101" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161327" legid="1491340102" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161328" legid="1491340103" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802791" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161330" legid="1491340104" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161332" legid="1491340105" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161334" legid="1491340106" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802792" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161336" legid="1491340107" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161338" legid="1491340108" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161340" legid="1491340109" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802793" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161342" legid="1491340110" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161344" legid="1491340111" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161346" legid="1491340112" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802794" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161348" legid="1491340113" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161349" legid="1491340114" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161350" legid="1491340115" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802795" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161351" legid="1491340116" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161352" legid="1491340117" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161353" legid="1491340118" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802796" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161354" legid="1491340119" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161355" legid="1491340120" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161356" legid="1491340121" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802797" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161357" legid="1491340122" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161358" legid="1491340123" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161359" legid="1491340124" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802798" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161360" legid="1491340125" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161361" legid="1491340126" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161362" legid="1491340127" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802799" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161363" legid="1491340128" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161364" legid="1491340129" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161365" legid="1491340130" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802800" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161366" legid="1491340131" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161367" legid="1491340132" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161368" legid="1491340133" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802801" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161369" legid="1491340134" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161370" legid="1491340135" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161371" legid="1491340136" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802802" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161372" legid="1491340137" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161373" legid="1491340138" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161374" legid="1491340139" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802803" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161375" legid="1491340140" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161376" legid="1491340141" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161377" legid="1491340142" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802804" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161378" legid="1491340143" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161379" legid="1491340144" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161380" legid="1491340145" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802805" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161381" legid="1491340146" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161382" legid="1491340147" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161383" legid="1491340148" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802806" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161384" legid="1491340149" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161385" legid="1491340150" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161386" legid="1491340151" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802807" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161387" legid="1491340152" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161388" legid="1491340153" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161389" legid="1491340154" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802808" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161390" legid="1491340155" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161391" legid="1491340156" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161392" legid="1491340157" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802809" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161393" legid="1491340158" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161394" legid="1491340159" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161395" legid="1491340160" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802810" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161396" legid="1491340161" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161397" legid="1491340162" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161398" legid="1491340163" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802811" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161399" legid="1491340164" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161400" legid="1491340165" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161401" legid="1491340166" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802812" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161402" legid="1491340167" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161403" legid="1491340168" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161404" legid="1491340169" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802813" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161405" legid="1491340170" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161406" legid="1491340171" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161407" legid="1491340172" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802814" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161408" legid="1491340173" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161409" legid="1491340174" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161410" legid="1491340175" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802815" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161411" legid="1491340176" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161412" legid="1491340177" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161413" legid="1491340178" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802816" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161414" legid="1491340179" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161415" legid="1491340180" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161416" legid="1491340181" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802817" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161417" legid="1491340182" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161518" legid="1491340337" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161519" legid="1491340338" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802818" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161520" legid="1491340339" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161521" legid="1491340340" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161522" legid="1491340341" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802819" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161523" legid="1491340342" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161524" legid="1491340343" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161525" legid="1491340344" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802820" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161526" legid="1491340345" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161527" legid="1491340346" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161528" legid="1491340347" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802821" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161529" legid="1491340348" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161530" legid="1491340349" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161531" legid="1491340350" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802822" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161532" legid="1491340351" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161533" legid="1491340352" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161534" legid="1491340353" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802823" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161535" legid="1491340354" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161536" legid="1491340355" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161537" legid="1491340356" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802824" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161538" legid="1491340357" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161539" legid="1491340358" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161540" legid="1491340359" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802825" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161541" legid="1491340360" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161542" legid="1491340361" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161543" legid="1491340362" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802826" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161544" legid="1491340363" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161545" legid="1491340364" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161546" legid="1491340365" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802827" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161547" legid="1491340366" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161548" legid="1491340367" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161549" legid="1491340368" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802828" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161550" legid="1491340369" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161551" legid="1491340370" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161552" legid="1491340371" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802829" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161553" legid="1491340372" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161554" legid="1491340373" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161555" legid="1491340374" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802830" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161556" legid="1491340375" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161557" legid="1491340376" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161558" legid="1491340377" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802831" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161559" legid="1491340378" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161560" legid="1491340379" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161561" legid="1491340380" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802832" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161562" legid="1491340381" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161563" legid="1491340382" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161564" legid="1491340383" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802833" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161565" legid="1491340384" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161566" legid="1491340385" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161567" legid="1491340386" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802834" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161568" legid="1491340387" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161569" legid="1491340388" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161570" legid="1491340389" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802835" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161571" legid="1491340390" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161572" legid="1491340391" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161573" legid="1491340392" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802836" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161574" legid="1491340393" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161575" legid="1491340394" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161576" legid="1491340395" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802837" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161577" legid="1491340396" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161578" legid="1491340397" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161579" legid="1491340398" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802838" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161580" legid="1491340399" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161581" legid="1491340400" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161582" legid="1491340401" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802839" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161583" legid="1491340402" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161584" legid="1491340403" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161585" legid="1491340404" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802840" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161586" legid="1491340405" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161587" legid="1491340406" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161588" legid="1491340407" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802841" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161589" legid="1491340408" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161590" legid="1491340409" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161591" legid="1491340410" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802842" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161592" legid="1491340411" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161593" legid="1491340412" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161594" legid="1491340413" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802843" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161595" legid="1491340414" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161596" legid="1491340415" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161597" legid="1491340416" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802844" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161598" legid="1491340417" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161599" legid="1491340418" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161600" legid="1491340419" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802845" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161601" legid="1491340420" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161602" legid="1491340421" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161603" legid="1491340422" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802846" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161604" legid="1491340423" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161605" legid="1491340424" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161606" legid="1491340425" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802847" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161607" legid="1491340426" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161608" legid="1491340427" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161609" legid="1491340428" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915667" adtbuy="1069.0" adtsell="1129.0" chdbuy="1069.0" chdsell="1129.0" infbuy="1069.0" infsell="1129.0" adttax="149.88" chdtax="149.88" inftax="149.88" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="EDEAL,ECSV,ECSV">
      <farexrefs>
        <farexref fareid="203915667">
          <flights>
            <flight flightid="1257803086" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161701" legid="1491340973" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161702" legid="1491340974" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161703" legid="1491340975" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915637" adtbuy="951.43" adtsell="1101.43" chdbuy="951.43" chdsell="1101.43" infbuy="951.43" infsell="951.43" adttax="207.67" chdtax="207.67" inftax="207.67" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915637">
          <flights>
            <flight flightid="1257802848" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161610" legid="1491340429" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161611" legid="1491340430" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161612" legid="1491340431" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802849" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161613" legid="1491340432" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161614" legid="1491340433" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161615" legid="1491340434" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802850" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161616" legid="1491340435" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161617" legid="1491340436" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161718" legid="1491340437" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802851" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161719" legid="1491340438" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161720" legid="1491340439" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161721" legid="1491340440" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802852" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161722" legid="1491340441" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161723" legid="1491340442" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161724" legid="1491340443" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802853" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161725" legid="1491340444" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161726" legid="1491340445" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161727" legid="1491340446" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802854" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161728" legid="1491340447" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161729" legid="1491340448" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161730" legid="1491340449" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802855" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161731" legid="1491340450" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161732" legid="1491340451" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161733" legid="1491340452" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802856" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161734" legid="1491340453" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161735" legid="1491340454" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161736" legid="1491340455" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802857" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161737" legid="1491340456" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161738" legid="1491340457" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161739" legid="1491340458" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802858" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161740" legid="1491340459" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161741" legid="1491340460" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161742" legid="1491340461" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802859" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161743" legid="1491340462" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161744" legid="1491340463" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161745" legid="1491340464" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802860" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161746" legid="1491340465" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161747" legid="1491340466" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161748" legid="1491340467" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802861" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161749" legid="1491340468" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161750" legid="1491340469" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161751" legid="1491340470" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802862" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161752" legid="1491340471" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161753" legid="1491340472" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161754" legid="1491340473" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802863" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161755" legid="1491340474" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161756" legid="1491340475" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161757" legid="1491340476" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802864" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161758" legid="1491340477" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161759" legid="1491340478" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161760" legid="1491340479" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802865" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161761" legid="1491340480" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161762" legid="1491340481" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161763" legid="1491340482" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802866" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161764" legid="1491340483" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161765" legid="1491340484" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161766" legid="1491340485" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802867" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161767" legid="1491340486" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161768" legid="1491340487" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161769" legid="1491340488" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802868" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161770" legid="1491340489" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161771" legid="1491340490" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161772" legid="1491340491" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802869" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161774" legid="1491340492" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161775" legid="1491340493" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161776" legid="1491340494" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802870" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161777" legid="1491340495" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161778" legid="1491340496" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161779" legid="1491340497" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802871" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161780" legid="1491340498" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161781" legid="1491340499" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161782" legid="1491340500" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802872" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161783" legid="1491340501" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161784" legid="1491340502" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161785" legid="1491340503" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802873" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161786" legid="1491340504" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161787" legid="1491340505" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161788" legid="1491340506" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802874" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161789" legid="1491340507" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161790" legid="1491340508" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161791" legid="1491340509" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802875" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161792" legid="1491340510" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161793" legid="1491340511" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161794" legid="1491340512" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802876" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161795" legid="1491340513" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161796" legid="1491340514" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161797" legid="1491340515" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915638" adtbuy="983.34" adtsell="1133.34" chdbuy="983.34" chdsell="1133.34" infbuy="983.34" infsell="983.34" adttax="207.67" chdtax="207.67" inftax="207.67" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915638">
          <flights>
            <flight flightid="1257802877" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161798" legid="1491340516" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161799" legid="1491340517" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161800" legid="1491340518" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802878" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161801" legid="1491340519" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161802" legid="1491340520" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161803" legid="1491340521" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802879" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161804" legid="1491340522" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161805" legid="1491340523" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161806" legid="1491340524" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802880" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161807" legid="1491340525" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161808" legid="1491340526" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161809" legid="1491340527" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915639" adtbuy="1014.32" adtsell="1164.32" chdbuy="1014.32" chdsell="1164.32" infbuy="1014.32" infsell="1014.32" adttax="207.67" chdtax="207.67" inftax="207.67" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915639">
          <flights>
            <flight flightid="1257802881" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161810" legid="1491340528" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161811" legid="1491340529" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161812" legid="1491340530" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802882" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161813" legid="1491340531" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161814" legid="1491340532" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161815" legid="1491340533" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802883" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161816" legid="1491340534" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161817" legid="1491340535" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
                <legxref legxrefid="225536161818" legid="1491340536" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SBLAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915668" adtbuy="1216.0" adtsell="1276.0" chdbuy="1216.0" chdsell="1276.0" infbuy="1216.0" infsell="1276.0" adttax="132.44" chdtax="132.44" inftax="132.44" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="EDEAL,ECSV,ECSV">
      <farexrefs>
        <farexref fareid="203915668">
          <flights>
            <flight flightid="1257803087" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161704" legid="1491340976" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="QIQW" seats="9">
                <legxref legxrefid="225536161705" legid="1491340977" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161706" legid="1491340978" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915640" adtbuy="1461.07" adtsell="1611.07" chdbuy="1461.07" chdsell="1611.07" infbuy="1461.07" infsell="1461.07" adttax="218.30" chdtax="218.30" inftax="218.30" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915640">
          <flights>
            <flight flightid="1257802884" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161820" legid="1491340637" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161821" legid="1491340638" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161822" legid="1491340639" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802885" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161823" legid="1491340640" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161824" legid="1491340641" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161825" legid="1491340642" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802886" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161826" legid="1491340643" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161827" legid="1491340644" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161828" legid="1491340645" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802887" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161829" legid="1491340646" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161830" legid="1491340647" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161831" legid="1491340648" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802888" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161832" legid="1491340649" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161833" legid="1491340650" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161834" legid="1491340651" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802889" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161835" legid="1491340652" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161836" legid="1491340653" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161837" legid="1491340654" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802890" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161838" legid="1491340655" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161839" legid="1491340656" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161840" legid="1491340657" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802891" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161841" legid="1491340658" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161842" legid="1491340659" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161843" legid="1491340660" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915641" adtbuy="1461.07" adtsell="1611.07" chdbuy="1461.07" chdsell="1611.07" infbuy="1461.07" infsell="1461.07" adttax="218.30" chdtax="218.30" inftax="218.30" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915641">
          <flights>
            <flight flightid="1257802892" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161844" legid="1491340661" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161845" legid="1491340662" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161846" legid="1491340663" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802893" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161847" legid="1491340664" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161848" legid="1491340665" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161849" legid="1491340666" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802894" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161850" legid="1491340667" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161851" legid="1491340668" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161852" legid="1491340669" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802895" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161853" legid="1491340670" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161854" legid="1491340671" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161855" legid="1491340672" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802896" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161856" legid="1491340673" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161857" legid="1491340674" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161858" legid="1491340675" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802897" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161859" legid="1491340676" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161860" legid="1491340677" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161861" legid="1491340678" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802898" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161862" legid="1491340679" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161863" legid="1491340680" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161864" legid="1491340681" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802899" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161865" legid="1491340682" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161866" legid="1491340683" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161867" legid="1491340684" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802900" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161868" legid="1491340685" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161869" legid="1491340686" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161870" legid="1491340687" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802901" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161871" legid="1491340688" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161872" legid="1491340689" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161873" legid="1491340690" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802902" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161874" legid="1491340691" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161875" legid="1491340692" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161876" legid="1491340693" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802903" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161877" legid="1491340694" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161878" legid="1491340695" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161879" legid="1491340696" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802904" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161880" legid="1491340697" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161881" legid="1491340698" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161882" legid="1491340699" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802905" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161883" legid="1491340700" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161884" legid="1491340701" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161885" legid="1491340702" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802906" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161886" legid="1491340703" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161887" legid="1491340704" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161888" legid="1491340705" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802907" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161889" legid="1491340706" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161890" legid="1491340707" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161891" legid="1491340708" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802908" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161892" legid="1491340709" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161893" legid="1491340710" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161894" legid="1491340711" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802909" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161895" legid="1491340712" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161896" legid="1491340713" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161897" legid="1491340714" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802910" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161898" legid="1491340715" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161899" legid="1491340716" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161900" legid="1491340717" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802911" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161901" legid="1491340718" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161902" legid="1491340719" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161903" legid="1491340720" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802912" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161904" legid="1491340721" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161905" legid="1491340722" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161906" legid="1491340723" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802913" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161907" legid="1491340724" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161908" legid="1491340725" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161909" legid="1491340726" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802914" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161910" legid="1491340727" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161911" legid="1491340728" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161912" legid="1491340729" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802915" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161913" legid="1491340730" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161914" legid="1491340731" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161915" legid="1491340732" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802916" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161916" legid="1491340733" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161917" legid="1491340734" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161918" legid="1491340735" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802917" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161919" legid="1491340736" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161923" legid="1491340837" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161924" legid="1491340838" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802918" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161925" legid="1491340839" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161926" legid="1491340840" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161927" legid="1491340841" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802919" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161928" legid="1491340842" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161929" legid="1491340843" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161930" legid="1491340844" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802920" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161931" legid="1491340845" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161932" legid="1491340846" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161933" legid="1491340847" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802921" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161934" legid="1491340848" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161935" legid="1491340849" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161936" legid="1491340850" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915643" adtbuy="1548.85" adtsell="1698.85" chdbuy="1548.85" chdsell="1698.85" infbuy="1548.85" infsell="1548.85" adttax="209.75" chdtax="209.75" inftax="209.75" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915643">
          <flights>
            <flight flightid="1257802924" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161943" legid="1491340857" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161944" legid="1491340858" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161945" legid="1491340859" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802925" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161946" legid="1491340860" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161947" legid="1491340861" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161948" legid="1491340862" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802926" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161949" legid="1491340863" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161950" legid="1491340864" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161951" legid="1491340865" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802927" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161952" legid="1491340866" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161953" legid="1491340867" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161954" legid="1491340868" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802928" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161955" legid="1491340869" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161956" legid="1491340870" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161957" legid="1491340871" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915642" adtbuy="1548.85" adtsell="1698.85" chdbuy="1548.85" chdsell="1698.85" infbuy="1548.85" infsell="1548.85" adttax="209.75" chdtax="209.75" inftax="209.75" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915642">
          <flights>
            <flight flightid="1257802922" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161937" legid="1491340851" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161938" legid="1491340852" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161939" legid="1491340853" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802923" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161940" legid="1491340854" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161941" legid="1491340855" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161942" legid="1491340856" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915663" adtbuy="1755.0" adtsell="1815.0" chdbuy="1755.0" chdsell="1815.0" infbuy="1755.0" infsell="1815.0" adttax="115.39" chdtax="115.39" inftax="115.39" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="ECFL,ECFL">
      <farexrefs>
        <farexref fareid="203915663">
          <flights>
            <flight flightid="1257803075" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161674" legid="1491340946" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HVAAO" seats="9">
                <legxref legxrefid="225536161675" legid="1491340947" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="HVAAO" seats="9">
              </legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803076" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161676" legid="1491340948" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HVAAO" seats="9">
                <legxref legxrefid="225536161677" legid="1491340949" class="Q" cos="E" cosdescription="ECONOMY" farebaseadt="HVAAO" seats="9">
              </legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915658" adtbuy="1789.0" adtsell="1849.0" chdbuy="1789.0" chdsell="1849.0" infbuy="1789.0" infsell="1849.0" adttax="147.74" chdtax="147.74" inftax="147.74" refundable="true" origin="BARGAINFINDERMAX" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell" farefamilies="ECFL,ECFL,ECFL">
      <farexrefs>
        <farexref fareid="203915658">
          <flights>
            <flight flightid="1257803017" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161313" legid="1491340621" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161315" legid="1491340622" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161320" legid="1491340623" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803018" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161322" legid="1491340624" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161324" legid="1491340625" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161326" legid="1491340626" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803019" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161329" legid="1491340627" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161331" legid="1491340628" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161333" legid="1491340629" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803020" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161335" legid="1491340630" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161337" legid="1491340631" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161339" legid="1491340632" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803021" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161341" legid="1491340633" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161343" legid="1491340634" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161345" legid="1491340635" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803022" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161347" legid="1491340636" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161418" legid="1491340737" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161419" legid="1491340738" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803023" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161420" legid="1491340739" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161421" legid="1491340740" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161422" legid="1491340741" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803024" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161423" legid="1491340742" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161424" legid="1491340743" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161425" legid="1491340744" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803025" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161426" legid="1491340745" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161427" legid="1491340746" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161428" legid="1491340747" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803026" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161429" legid="1491340748" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161430" legid="1491340749" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161431" legid="1491340750" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803027" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161432" legid="1491340751" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161433" legid="1491340752" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161434" legid="1491340753" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803028" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161435" legid="1491340754" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161436" legid="1491340755" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161437" legid="1491340756" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803029" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161438" legid="1491340757" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161439" legid="1491340758" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161440" legid="1491340759" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257803030" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161441" legid="1491340760" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161442" legid="1491340761" class="H" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
                <legxref legxrefid="225536161443" legid="1491340762" class="O" cos="E" cosdescription="ECONOMY" farebaseadt="HBLAOUQV" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
    <tarif tarifid="203915644" adtbuy="1791.23" adtsell="1941.23" chdbuy="1791.23" chdsell="1941.23" infbuy="1791.23" infsell="1791.23" adttax="192.35" chdtax="192.35" inftax="192.35" origin="MASTERPRICER-XML" taxmode="EXCL" topcar="false" tophotel="false" powerpricerdisplay="sell">
      <farexrefs>
        <farexref fareid="203915644">
          <flights>
            <flight flightid="1257802929" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161958" legid="1491340872" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161959" legid="1491340873" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161960" legid="1491340874" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
            <flight flightid="1257802930" addadtprice="0.0" addchdprice="0.0" addinfprice="0.0">
              <legxrefs>
                <legxref legxrefid="225536161961" legid="1491340875" class="K" cos="E" cosdescription="ECONOMY" farebaseadt="KIQW" seats="9">
                <legxref legxrefid="225536161962" legid="1491340876" class="S" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
                <legxref legxrefid="225536161963" legid="1491340877" class="N" cos="E" cosdescription="ECONOMY" farebaseadt="SVAAO" seats="9">
              </legxref></legxref></legxref></legxrefs>
            </flight>
          </flights>
        </farexref>
      </farexrefs>
    </tarif>
  </tarifs>
  <legs>
    <leg legid="1491339969" depapt="MEL" depdate="2025-02-12" deptime="12:05" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="17:05" equip="332" fno="35" shared:cr="QF" miles="3755" elapsed="8.0" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339970" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="32Q" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339983" depapt="MEL" depdate="2025-02-12" deptime="12:05" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="17:05" equip="332" fno="35" shared:cr="QF" miles="3755" elapsed="8.0" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339984" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339985" depapt="MEL" depdate="2025-02-12" deptime="16:55" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="22:05" equip="332" fno="37" shared:cr="QF" miles="3755" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339986" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339987" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339988" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339989" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339990" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339991" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339992" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339993" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339994" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339995" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339996" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339997" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491339998" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491339999" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340000" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340001" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340002" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340003" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340004" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340005" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340006" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340007" depapt="BLR" depdate="2025-02-12" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340008" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340009" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340010" depapt="BLR" depdate="2025-02-12" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340011" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340012" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340013" depapt="BLR" depdate="2025-02-12" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340014" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340015" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340016" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340017" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340018" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340019" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340020" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340021" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340022" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340023" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340024" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340025" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340026" depapt="MEL" depdate="2025-02-12" deptime="19:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:25" equip="73H" fno="486" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340027" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340028" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340029" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340030" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340031" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340032" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340033" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340034" depapt="BLR" depdate="2025-02-13" deptime="07:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="09:55" equip="321" fno="5331" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340035" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340036" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340037" depapt="BLR" depdate="2025-02-13" deptime="07:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="09:55" equip="321" fno="5331" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340038" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340039" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340040" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340041" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340042" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340043" depapt="BLR" depdate="2025-02-13" deptime="07:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="09:55" equip="321" fno="5331" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340044" depapt="MEL" depdate="2025-02-12" deptime="18:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="19:25" equip="73H" fno="478" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340045" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340046" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340047" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340048" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340049" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340050" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340051" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340052" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340053" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340054" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340055" depapt="BLR" depdate="2025-02-13" deptime="08:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="11:00" equip="321" fno="5035" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340056" depapt="MEL" depdate="2025-02-12" deptime="17:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:55" equip="73H" fno="474" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340057" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340058" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340059" depapt="MEL" depdate="2025-02-12" deptime="19:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:25" equip="73H" fno="486" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340060" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340061" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340062" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340063" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340064" depapt="BLR" depdate="2025-02-13" deptime="08:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="11:00" equip="321" fno="5035" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340065" depapt="MEL" depdate="2025-02-12" deptime="17:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:40" equip="73H" fno="472" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340066" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340067" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340068" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340069" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340070" depapt="BLR" depdate="2025-02-13" deptime="08:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="11:00" equip="321" fno="5035" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340071" depapt="MEL" depdate="2025-02-12" deptime="17:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:25" equip="73H" fno="470" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340072" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340073" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340074" depapt="MEL" depdate="2025-02-12" deptime="16:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:10" equip="73H" fno="468" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340075" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340076" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340077" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340078" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340079" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340080" depapt="MEL" depdate="2025-02-12" deptime="16:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:55" equip="73H" fno="466" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340081" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340082" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340083" depapt="MEL" depdate="2025-02-12" deptime="18:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="19:25" equip="73H" fno="478" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340084" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340085" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340086" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340087" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340088" depapt="BLR" depdate="2025-02-13" deptime="09:15" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="12:05" equip="321" fno="5346" shared:cr="QF" miles="1081" elapsed="2.83" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340089" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340090" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340091" depapt="BLR" depdate="2025-02-13" deptime="09:15" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="12:05" equip="321" fno="5346" shared:cr="QF" miles="1081" elapsed="2.83" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340092" depapt="MEL" depdate="2025-02-12" deptime="16:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:40" equip="73H" fno="464" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340093" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340094" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340095" depapt="MEL" depdate="2025-02-12" deptime="19:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:25" equip="73H" fno="486" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340096" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340097" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340098" depapt="MEL" depdate="2025-02-12" deptime="16:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:25" equip="73H" fno="462" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340099" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340100" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340101" depapt="MEL" depdate="2025-02-12" deptime="17:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:55" equip="73H" fno="474" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340102" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340103" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340104" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340105" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340106" depapt="BLR" depdate="2025-02-13" deptime="09:15" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="12:05" equip="321" fno="5346" shared:cr="QF" miles="1081" elapsed="2.83" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340107" depapt="MEL" depdate="2025-02-12" deptime="17:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:40" equip="73H" fno="472" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340108" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340109" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340110" depapt="MEL" depdate="2025-02-12" deptime="15:35" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:00" equip="73H" fno="460" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340111" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340112" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340113" depapt="MEL" depdate="2025-02-12" deptime="17:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:25" equip="73H" fno="470" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340114" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340115" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340116" depapt="MEL" depdate="2025-02-12" deptime="16:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:10" equip="73H" fno="468" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340117" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340118" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340119" depapt="MEL" depdate="2025-02-12" deptime="18:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="19:25" equip="73H" fno="478" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340120" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340121" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340122" depapt="MEL" depdate="2025-02-12" deptime="16:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:55" equip="73H" fno="466" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340123" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340124" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340125" depapt="MEL" depdate="2025-02-12" deptime="16:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:40" equip="73H" fno="464" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340126" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340127" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340128" depapt="MEL" depdate="2025-02-12" deptime="17:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:55" equip="73H" fno="474" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340129" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340130" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340131" depapt="MEL" depdate="2025-02-12" deptime="14:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:55" equip="73H" fno="450" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340132" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340133" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340134" depapt="MEL" depdate="2025-02-12" deptime="16:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:25" equip="73H" fno="462" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340135" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340136" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340137" depapt="MEL" depdate="2025-02-12" deptime="17:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:40" equip="73H" fno="472" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340138" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340139" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340140" depapt="MEL" depdate="2025-02-12" deptime="17:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:25" equip="73H" fno="470" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340141" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340142" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340143" depapt="MEL" depdate="2025-02-12" deptime="15:35" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:00" equip="73H" fno="460" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340144" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340145" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340146" depapt="MEL" depdate="2025-02-12" deptime="14:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:25" equip="73H" fno="448" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340147" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340148" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340149" depapt="MEL" depdate="2025-02-12" deptime="16:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:10" equip="73H" fno="468" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340150" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340151" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340152" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340153" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340154" depapt="BLR" depdate="2025-02-13" deptime="11:45" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="14:40" equip="321" fno="5041" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340155" depapt="MEL" depdate="2025-02-12" deptime="16:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:55" equip="73H" fno="466" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340156" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340157" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340158" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340159" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340160" depapt="BLR" depdate="2025-02-13" deptime="11:45" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="14:40" equip="321" fno="5041" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340161" depapt="MEL" depdate="2025-02-12" deptime="16:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:40" equip="73H" fno="464" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340162" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340163" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340164" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340165" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340166" depapt="BLR" depdate="2025-02-13" deptime="11:45" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="14:40" equip="321" fno="5041" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340167" depapt="MEL" depdate="2025-02-12" deptime="16:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:25" equip="73H" fno="462" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340168" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340169" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340170" depapt="MEL" depdate="2025-02-12" deptime="13:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="14:25" equip="73H" fno="444" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340171" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340172" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340173" depapt="MEL" depdate="2025-02-12" deptime="14:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:55" equip="73H" fno="450" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340174" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340175" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340176" depapt="MEL" depdate="2025-02-12" deptime="15:35" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:00" equip="73H" fno="460" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340177" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340178" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340179" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340180" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340181" depapt="BLR" depdate="2025-02-13" deptime="13:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="15:50" equip="321" fno="5329" shared:cr="QF" miles="1081" elapsed="2.83" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340182" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340337" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340338" depapt="BLR" depdate="2025-02-13" deptime="13:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="15:50" equip="321" fno="5329" shared:cr="QF" miles="1081" elapsed="2.83" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340339" depapt="MEL" depdate="2025-02-12" deptime="14:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:25" equip="73H" fno="448" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340340" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340341" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340342" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340343" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340344" depapt="BLR" depdate="2025-02-13" deptime="13:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="15:50" equip="321" fno="5329" shared:cr="QF" miles="1081" elapsed="2.83" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340345" depapt="MEL" depdate="2025-02-12" deptime="12:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="13:25" equip="73H" fno="440" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340346" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340347" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340348" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340349" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340350" depapt="BLR" depdate="2025-02-13" deptime="14:00" dstapt="DEL" depterm="1" arrterm="3" arrdate="2025-02-13" arrtime="16:45" equip="321" fno="5039" shared:cr="QF" miles="1081" elapsed="2.75" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340351" depapt="MEL" depdate="2025-02-12" deptime="14:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:55" equip="73H" fno="450" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340352" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340353" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340354" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340355" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340356" depapt="BLR" depdate="2025-02-13" deptime="14:00" dstapt="DEL" depterm="1" arrterm="3" arrdate="2025-02-13" arrtime="16:45" equip="321" fno="5039" shared:cr="QF" miles="1081" elapsed="2.75" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340357" depapt="MEL" depdate="2025-02-12" deptime="13:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="14:25" equip="73H" fno="444" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340358" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340359" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340360" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340361" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340362" depapt="BLR" depdate="2025-02-13" deptime="14:00" dstapt="DEL" depterm="1" arrterm="3" arrdate="2025-02-13" arrtime="16:45" equip="321" fno="5039" shared:cr="QF" miles="1081" elapsed="2.75" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340363" depapt="MEL" depdate="2025-02-12" deptime="11:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:40" equip="73H" fno="442" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340364" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340365" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340366" depapt="MEL" depdate="2025-02-12" deptime="14:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:25" equip="73H" fno="448" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340367" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340368" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340369" depapt="MEL" depdate="2025-02-12" deptime="11:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:25" equip="73H" fno="436" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340370" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340371" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340372" depapt="MEL" depdate="2025-02-12" deptime="10:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:55" equip="73H" fno="434" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340373" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340374" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340375" depapt="MEL" depdate="2025-02-12" deptime="12:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="13:25" equip="73H" fno="440" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340376" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340377" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340378" depapt="MEL" depdate="2025-02-12" deptime="13:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="14:25" equip="73H" fno="444" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340379" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340380" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340381" depapt="MEL" depdate="2025-02-12" deptime="10:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:25" equip="73H" fno="432" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340382" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340383" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340384" depapt="MEL" depdate="2025-02-12" deptime="11:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:40" equip="73H" fno="442" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340385" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340386" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340387" depapt="MEL" depdate="2025-02-12" deptime="09:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:55" equip="73H" fno="430" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340388" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340389" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340390" depapt="MEL" depdate="2025-02-12" deptime="11:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:25" equip="73H" fno="436" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340391" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340392" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340393" depapt="MEL" depdate="2025-02-12" deptime="09:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:40" equip="73H" fno="428" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340394" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340395" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340396" depapt="MEL" depdate="2025-02-12" deptime="12:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="13:25" equip="73H" fno="440" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340397" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340398" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340399" depapt="MEL" depdate="2025-02-12" deptime="09:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:25" equip="73H" fno="426" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340400" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340401" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340402" depapt="MEL" depdate="2025-02-12" deptime="10:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:55" equip="73H" fno="434" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340403" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340404" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340405" depapt="MEL" depdate="2025-02-12" deptime="08:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="09:55" equip="73H" fno="422" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340406" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340407" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340408" depapt="MEL" depdate="2025-02-12" deptime="10:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:25" equip="73H" fno="432" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340409" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340410" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340411" depapt="MEL" depdate="2025-02-12" deptime="11:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:40" equip="73H" fno="442" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340412" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340413" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340414" depapt="MEL" depdate="2025-02-12" deptime="08:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="09:40" equip="73H" fno="420" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340415" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340416" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340417" depapt="MEL" depdate="2025-02-12" deptime="11:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:25" equip="73H" fno="436" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340418" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340419" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340420" depapt="MEL" depdate="2025-02-12" deptime="09:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:55" equip="73H" fno="430" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340421" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340422" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340423" depapt="MEL" depdate="2025-02-12" deptime="09:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:40" equip="73H" fno="428" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340424" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340425" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340426" depapt="MEL" depdate="2025-02-12" deptime="09:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:25" equip="73H" fno="426" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340427" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340428" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340429" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340430" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340431" depapt="BLR" depdate="2025-02-12" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340432" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340433" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340434" depapt="BLR" depdate="2025-02-12" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340435" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340436" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340437" depapt="BLR" depdate="2025-02-12" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340438" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340439" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340440" depapt="BLR" depdate="2025-02-13" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340441" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340442" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340443" depapt="BLR" depdate="2025-02-13" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340444" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340445" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340446" depapt="BLR" depdate="2025-02-13" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340447" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340448" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340449" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340450" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340451" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340452" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340453" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340454" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340455" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340456" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340457" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340458" depapt="BLR" depdate="2025-02-13" deptime="10:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="13:25" equip="321" fno="5045" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340459" depapt="MEL" depdate="2025-02-12" deptime="19:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:25" equip="73H" fno="486" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340460" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340461" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340462" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340463" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340464" depapt="BLR" depdate="2025-02-13" deptime="10:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="13:25" equip="321" fno="5045" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340465" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340466" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340467" depapt="BLR" depdate="2025-02-13" deptime="10:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="13:25" equip="321" fno="5045" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340468" depapt="MEL" depdate="2025-02-12" deptime="18:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="19:25" equip="73H" fno="478" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340469" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340470" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340471" depapt="MEL" depdate="2025-02-12" deptime="17:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:55" equip="73H" fno="474" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340472" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340473" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340474" depapt="MEL" depdate="2025-02-12" deptime="17:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:40" equip="73H" fno="472" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340475" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340476" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340477" depapt="MEL" depdate="2025-02-12" deptime="17:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:25" equip="73H" fno="470" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340478" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340479" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340480" depapt="MEL" depdate="2025-02-12" deptime="16:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:10" equip="73H" fno="468" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340481" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340482" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340483" depapt="MEL" depdate="2025-02-12" deptime="16:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:55" equip="73H" fno="466" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340484" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340485" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340486" depapt="MEL" depdate="2025-02-12" deptime="16:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:40" equip="73H" fno="464" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340487" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340488" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340489" depapt="MEL" depdate="2025-02-12" deptime="16:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:25" equip="73H" fno="462" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340490" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340491" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340492" depapt="MEL" depdate="2025-02-12" deptime="15:35" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:00" equip="73H" fno="460" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340493" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340494" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340495" depapt="MEL" depdate="2025-02-12" deptime="14:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:55" equip="73H" fno="450" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340496" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340497" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340498" depapt="MEL" depdate="2025-02-12" deptime="14:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:25" equip="73H" fno="448" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340499" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340500" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340501" depapt="MEL" depdate="2025-02-12" deptime="13:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="14:25" equip="73H" fno="444" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340502" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340503" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340504" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340505" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340506" depapt="BLR" depdate="2025-02-14" deptime="07:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="09:55" equip="321" fno="5331" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340507" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340508" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340509" depapt="BLR" depdate="2025-02-14" deptime="07:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="09:55" equip="321" fno="5331" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340510" depapt="MEL" depdate="2025-02-12" deptime="12:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="13:25" equip="73H" fno="440" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340511" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340512" depapt="BLR" depdate="2025-02-13" deptime="23:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="01:55" equip="321" fno="5333" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340513" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340514" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340515" depapt="BLR" depdate="2025-02-14" deptime="08:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="11:00" equip="321" fno="5035" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340516" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340517" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340518" depapt="BLR" depdate="2025-02-14" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340519" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340520" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340521" depapt="BLR" depdate="2025-02-14" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340522" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340523" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340524" depapt="BLR" depdate="2025-02-14" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340525" depapt="MEL" depdate="2025-02-12" deptime="19:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:25" equip="73H" fno="486" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340526" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340527" depapt="BLR" depdate="2025-02-14" deptime="05:35" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="08:35" equip="321" fno="5036" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340528" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340529" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340530" depapt="BLR" depdate="2025-02-13" deptime="15:20" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="18:05" equip="321" fno="5280" shared:cr="QF" miles="1081" elapsed="2.75" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340531" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340532" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340533" depapt="BLR" depdate="2025-02-13" deptime="15:20" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="18:05" equip="321" fno="5280" shared:cr="QF" miles="1081" elapsed="2.75" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340534" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340535" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340536" depapt="BLR" depdate="2025-02-13" deptime="15:20" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="18:05" equip="321" fno="5280" shared:cr="QF" miles="1081" elapsed="2.75" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340537" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340538" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340539" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340540" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340541" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340542" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340543" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340544" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340545" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340546" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340547" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340548" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340549" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340550" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340551" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340552" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340553" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340554" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340555" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340556" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340557" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340558" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340559" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340560" depapt="BLR" depdate="2025-02-12" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340561" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340562" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340563" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340564" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340565" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340566" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340567" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340568" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340569" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340570" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340571" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340572" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340573" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340574" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340575" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340576" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340577" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340578" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340579" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340580" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340581" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340582" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340583" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340584" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340585" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340586" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340587" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340588" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340589" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340590" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340591" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340592" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340593" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340594" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340595" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340596" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340597" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340598" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340599" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340600" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340601" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340602" depapt="BLR" depdate="2025-02-12" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340603" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340604" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340605" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340606" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340607" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340608" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340609" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340610" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340611" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340612" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340613" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340614" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340615" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340616" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340617" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340618" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340619" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340620" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340621" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340622" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340623" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340624" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340625" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340626" depapt="BLR" depdate="2025-02-13" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-14" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340627" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340628" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340629" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340630" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340631" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340632" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340633" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340634" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340635" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340636" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340637" depapt="MEL" depdate="2025-02-12" deptime="08:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="09:25" equip="73H" fno="418" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340638" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340639" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340640" depapt="MEL" depdate="2025-02-12" deptime="07:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="09:10" equip="73H" fno="416" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340641" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    <leg legid="1491340642" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    <leg legid="1491340643" depapt="MEL" depdate="2025-02-12" deptime="07:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="08:55" equip="73H" fno="414" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340644" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340645" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340646" depapt="MEL" depdate="2025-02-12" deptime="07:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="08:25" equip="73H" fno="410" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340647" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340648" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340649" depapt="MEL" depdate="2025-02-12" deptime="06:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="08:10" equip="73H" fno="408" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340650" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340651" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340652" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340653" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340654" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340655" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340656" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340657" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340658" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340659" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340660" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340661" depapt="MEL" depdate="2025-02-12" deptime="21:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="22:25" equip="73H" fno="498" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340662" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340663" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340664" depapt="MEL" depdate="2025-02-12" deptime="20:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="21:55" equip="73H" fno="496" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340665" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340666" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340667" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340668" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340669" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340670" depapt="MEL" depdate="2025-02-12" deptime="19:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:25" equip="73H" fno="486" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340671" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340672" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340673" depapt="MEL" depdate="2025-02-12" deptime="18:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="19:25" equip="73H" fno="478" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340674" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340675" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340676" depapt="MEL" depdate="2025-02-12" deptime="17:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:55" equip="73H" fno="474" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340677" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340678" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340679" depapt="MEL" depdate="2025-02-12" deptime="17:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:40" equip="73H" fno="472" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340680" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340681" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340682" depapt="MEL" depdate="2025-02-12" deptime="17:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:25" equip="73H" fno="470" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340683" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340684" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340685" depapt="MEL" depdate="2025-02-12" deptime="16:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="18:10" equip="73H" fno="468" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340686" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340687" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340688" depapt="MEL" depdate="2025-02-12" deptime="16:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:55" equip="73H" fno="466" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340689" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340690" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340691" depapt="MEL" depdate="2025-02-12" deptime="16:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:40" equip="73H" fno="464" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340692" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340693" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340694" depapt="MEL" depdate="2025-02-12" deptime="16:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:25" equip="73H" fno="462" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340695" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340696" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340697" depapt="MEL" depdate="2025-02-12" deptime="15:35" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="17:00" equip="73H" fno="460" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340698" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340699" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340700" depapt="MEL" depdate="2025-02-12" deptime="14:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:55" equip="73H" fno="450" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340701" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340702" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340703" depapt="MEL" depdate="2025-02-12" deptime="14:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="15:25" equip="73H" fno="448" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340704" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340705" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340706" depapt="MEL" depdate="2025-02-12" deptime="13:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="14:25" equip="73H" fno="444" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340707" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340708" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340709" depapt="MEL" depdate="2025-02-12" deptime="13:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="14:25" equip="73H" fno="444" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340710" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340711" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340712" depapt="MEL" depdate="2025-02-12" deptime="12:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="13:25" equip="73H" fno="440" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340713" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340714" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340715" depapt="MEL" depdate="2025-02-12" deptime="12:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="13:25" equip="73H" fno="440" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340716" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340717" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340718" depapt="MEL" depdate="2025-02-12" deptime="11:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:40" equip="73H" fno="442" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340719" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340720" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340721" depapt="MEL" depdate="2025-02-12" deptime="11:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:40" equip="73H" fno="442" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340722" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340723" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340724" depapt="MEL" depdate="2025-02-12" deptime="11:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:25" equip="73H" fno="436" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340725" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340726" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340727" depapt="MEL" depdate="2025-02-12" deptime="11:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="12:25" equip="73H" fno="436" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340728" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340729" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340730" depapt="MEL" depdate="2025-02-12" deptime="10:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:55" equip="73H" fno="434" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340731" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340732" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340733" depapt="MEL" depdate="2025-02-12" deptime="10:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:55" equip="73H" fno="434" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340734" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340735" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340736" depapt="MEL" depdate="2025-02-12" deptime="10:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:25" equip="73H" fno="432" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340737" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340738" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340739" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340740" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340741" depapt="BLR" depdate="2025-02-13" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340742" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340743" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340744" depapt="BLR" depdate="2025-02-12" deptime="21:50" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="00:45" equip="321" fno="5282" shared:cr="QF" miles="1081" elapsed="2.92" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340745" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340746" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340747" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340748" depapt="MEL" depdate="2025-02-12" deptime="06:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:55" equip="73H" fno="406" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340749" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340750" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340751" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340752" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340753" depapt="BLR" depdate="2025-02-12" deptime="19:00" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="22:00" equip="321" fno="5042" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340754" depapt="MEL" depdate="2025-02-12" deptime="06:20" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:45" equip="73H" fno="404" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340755" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340756" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340757" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="07:25" equip="73H" fno="402" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340758" depapt="SYD" depdate="2025-02-12" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-12" arrtime="15:55" equip="333" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340759" depapt="BLR" depdate="2025-02-12" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-12" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340760" depapt="MEL" depdate="2025-02-12" deptime="19:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="20:55" equip="73H" fno="490" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340761" depapt="SYD" depdate="2025-02-13" deptime="09:30" dstapt="BLR" depterm="1" arrterm="2" arrdate="2025-02-13" arrtime="15:55" equip="332" fno="67" shared:cr="QF" miles="5810" elapsed="12.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340762" depapt="BLR" depdate="2025-02-13" deptime="20:30" dstapt="DEL" depterm="1" arrterm="1D" arrdate="2025-02-13" arrtime="23:30" equip="321" fno="5040" shared:cr="QF" miles="1081" elapsed="3.0" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340837" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340838" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340839" depapt="MEL" depdate="2025-02-12" deptime="10:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="11:25" equip="73H" fno="432" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340840" depapt="SYD" depdate="2025-02-13" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-13" arrtime="16:30" equip="332" fno="81" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340841" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340842" depapt="MEL" depdate="2025-02-12" deptime="09:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:55" equip="73H" fno="430" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340843" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340844" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340845" depapt="MEL" depdate="2025-02-12" deptime="09:15" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:40" equip="73H" fno="428" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340846" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340847" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340848" depapt="MEL" depdate="2025-02-12" deptime="09:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="10:25" equip="73H" fno="426" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340849" depapt="SYD" depdate="2025-02-12" deptime="15:55" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="21:05" equip="388" fno="1" shared:cr="QF" miles="3915" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340850" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340851" depapt="MEL" depdate="2025-02-12" deptime="06:45" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="08:00" equip="73H" fno="604" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340852" depapt="BNE" depdate="2025-02-12" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-12" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340853" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340854" depapt="MEL" depdate="2025-02-12" deptime="06:00" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="07:15" equip="73H" fno="600" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340855" depapt="BNE" depdate="2025-02-12" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-12" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340856" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340857" depapt="MEL" depdate="2025-02-12" deptime="20:25" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="21:40" equip="223" fno="1262" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340858" depapt="BNE" depdate="2025-02-13" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-13" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340859" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340860" depapt="MEL" depdate="2025-02-12" deptime="18:25" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="19:40" equip="73H" fno="632" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340861" depapt="BNE" depdate="2025-02-13" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-13" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340862" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340863" depapt="MEL" depdate="2025-02-12" deptime="17:25" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="18:40" equip="73H" fno="628" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340864" depapt="BNE" depdate="2025-02-13" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-13" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340865" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340866" depapt="MEL" depdate="2025-02-12" deptime="16:45" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="18:00" equip="73H" fno="626" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340867" depapt="BNE" depdate="2025-02-13" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-13" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340868" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340869" depapt="MEL" depdate="2025-02-12" deptime="15:20" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="16:35" equip="73H" fno="622" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340870" depapt="BNE" depdate="2025-02-13" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-13" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340871" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340872" depapt="MEL" depdate="2025-02-12" deptime="08:20" dstapt="PER" depterm="1" arrterm="4" arrdate="2025-02-12" arrtime="09:25" equip="332" fno="769" shared:cr="QF" miles="1681" elapsed="4.08" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340873" depapt="PER" depdate="2025-02-12" deptime="12:25" dstapt="SIN" depterm="4" arrterm="1" arrdate="2025-02-12" arrtime="17:55" equip="332" fno="71" shared:cr="QF" miles="2434" elapsed="5.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340874" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340875" depapt="MEL" depdate="2025-02-12" deptime="06:40" dstapt="PER" depterm="1" arrterm="4" arrdate="2025-02-12" arrtime="07:45" equip="332" fno="767" shared:cr="QF" miles="1681" elapsed="4.08" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340876" depapt="PER" depdate="2025-02-12" deptime="12:25" dstapt="SIN" depterm="4" arrterm="1" arrdate="2025-02-12" arrtime="17:55" equip="332" fno="71" shared:cr="QF" miles="2434" elapsed="5.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340877" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340942" depapt="MEL" depdate="2025-02-12" deptime="12:05" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="17:05" equip="332" fno="35" shared:cr="QF" miles="3755" elapsed="8.0" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340943" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340944" depapt="MEL" depdate="2025-02-12" deptime="16:55" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="22:05" equip="332" fno="37" shared:cr="QF" miles="3755" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340945" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340946" depapt="MEL" depdate="2025-02-12" deptime="12:05" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="17:05" equip="332" fno="35" shared:cr="QF" miles="3755" elapsed="8.0" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340947" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340948" depapt="MEL" depdate="2025-02-12" deptime="16:55" dstapt="SIN" depterm="2" arrterm="1" arrdate="2025-02-12" arrtime="22:05" equip="332" fno="37" shared:cr="QF" miles="3755" elapsed="8.17" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340949" depapt="SIN" depdate="2025-02-13" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-13" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340958" depapt="MEL" depdate="2025-02-12" deptime="07:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="08:25" equip="73H" fno="410" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340959" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340960" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340961" depapt="MEL" depdate="2025-02-12" deptime="08:00" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="09:25" equip="73H" fno="418" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340962" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340963" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340964" depapt="MEL" depdate="2025-02-12" deptime="07:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="09:10" equip="73H" fno="416" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340965" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340966" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340967" depapt="MEL" depdate="2025-02-12" deptime="07:30" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="08:55" equip="73H" fno="414" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340968" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340969" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340970" depapt="MEL" depdate="2025-02-12" deptime="06:45" dstapt="SYD" depterm="1" arrterm="3" arrdate="2025-02-12" arrtime="08:10" equip="73H" fno="408" shared:cr="QF" miles="439" elapsed="1.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340971" depapt="SYD" depdate="2025-02-12" deptime="11:00" dstapt="SIN" depterm="1" arrterm="1" arrdate="2025-02-12" arrtime="16:30" equip="333" fno="291" shared:cr="QF" miles="3915" elapsed="8.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340972" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340973" depapt="MEL" depdate="2025-02-12" deptime="06:45" dstapt="BNE" depterm="1" arrterm="D" arrdate="2025-02-12" arrtime="08:00" equip="73H" fno="604" shared:cr="QF" miles="859" elapsed="2.25" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340974" depapt="BNE" depdate="2025-02-12" deptime="10:35" dstapt="SIN" depterm="I" arrterm="1" arrdate="2025-02-12" arrtime="17:00" equip="332" fno="51" shared:cr="QF" miles="3823" elapsed="8.42" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340975" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
    </leg><leg legid="1491340976" depapt="MEL" depdate="2025-02-12" deptime="08:20" dstapt="PER" depterm="1" arrterm="4" arrdate="2025-02-12" arrtime="09:25" equip="332" fno="769" shared:cr="QF" miles="1681" elapsed="4.08" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340977" depapt="PER" depdate="2025-02-12" deptime="12:25" dstapt="SIN" depterm="4" arrterm="1" arrdate="2025-02-12" arrtime="17:55" equip="332" fno="71" shared:cr="QF" miles="2434" elapsed="5.5" meals="0" smoker="false" stops="0" eticket="true">
    </leg><leg legid="1491340978" depapt="SIN" depdate="2025-02-12" deptime="19:40" dstapt="DEL" depterm="2" arrterm="3" arrdate="2025-02-12" arrtime="23:20" equip="321" fno="8764" shared:cr="QF" miles="2586" elapsed="6.67" meals="0" smoker="false" stops="0" eticket="true" shared:ocr="6E">
  </leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></leg></legs>
  <taxes shared:currency="AUD">
    <tax shared:vcr="QF" shared:faretype="PUB">104.38</tax>
    <tax shared:vcr="QF" shared:faretype="CPN">104.38</tax>
  </taxes>
  <advtaxes shared:currency="AUD">
    <advtax shared:vcr="QF" routing="QF_MELSYD0:QF_SYDBLR0:QF_BLRDEL0" adtprice="147.74">
    <advtax shared:vcr="QF" routing="QF_MELSIN0:QF_SINDEL0" adtprice="115.39">
    <advtax shared:vcr="QF" routing="QF_MELSYD0:QF_SYDSIN0:QF_SINDEL0" adtprice="158.44">
    <advtax shared:vcr="QF" routing="QF_MELBNE0:QF_BNESIN0:QF_SINDEL0" adtprice="149.88">
    <advtax shared:vcr="QF" routing="QF_MELPER0:QF_PERSIN0:QF_SINDEL0" adtprice="132.44">
    <advtax shared:vcr="QF" routing="QF_AVVSYD0:QF_SYDBLR0:QF_BLRDEL0" adtprice="122.31">
  </advtax></advtax></advtax></advtax></advtax></advtax></advtaxes>
  <shared:specialservices><servicegroup identifier="baggage"><service identifier="fba" description="Free Baggage Allowance" applicablepaxtypes="ADT"><selectiongroup><item id="FBA_1" unit="kg" totalallowance="30"></item><item id="FBA_2" unit="kg" totalallowance="40"></item></selectiongroup></service></servicegroup><servicegroup identifier="farefamily"><service identifier="bf" description="Benefits"><selectiongroup selectiontype="check"><item id="BF_1" farefamily="ECSL" farefamilydescription="ECONOMY SALE" description="QFINTERNATIONAL 02" programid="155527"></item><item id="BF_2" farefamily="ECSV" farefamilydescription="ECONOMY SAVER" description="QFINTERNATIONAL 02" programid="155527"></item><item id="BF_3" farefamily="ECFL" farefamilydescription="ECONOMY FLEX" description="QFINTERNATIONAL 02" programid="155527"></item><item id="BF_4" farefamily="EDEAL" farefamilydescription="RED EDEAL" description="QFAUDOM 02" programid="158250"></item></selectiongroup></service></servicegroup></shared:specialservices>
  <servicemappings><map elemtype="legXRef" elemid="225536160950" servicegroup="baggage" serviceid="FBA_1"></map><map elemtype="legXRef" elemid="225536160951" servicegroup="baggage" serviceid="FBA_1"></map><map elemtype="legXRef" elemid="225536161118" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161119" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161120" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161121" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161122" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161123" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161124" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161125" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161126" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161127" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161128" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161129" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161130" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161131" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161132" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161133" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161134" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161135" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161136" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161137" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161138" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161139" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161140" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161141" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161142" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161143" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161144" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161145" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161146" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161147" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161148" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161149" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161150" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161151" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161152" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161153" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161154" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161155" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161156" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161157" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161158" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161159" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161160" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161161" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161162" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161163" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161164" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161165" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161166" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161167" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161168" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161169" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161170" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161171" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161172" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161173" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161174" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161175" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161176" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161177" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161178" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161179" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161180" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161181" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161182" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161183" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161184" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161185" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161186" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161187" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161188" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161189" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161190" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161191" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161192" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161193" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161194" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161195" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161196" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161197" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161198" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161199" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161200" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161201" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161202" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161203" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161204" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161205" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161206" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161207" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161208" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161209" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161210" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161211" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161212" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161213" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161214" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161215" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161216" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161217" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161291" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161295" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161297" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161298" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161300" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161302" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161304" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161306" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161308" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161310" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161312" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161314" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161316" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161317" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161318" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161319" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161321" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161323" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161325" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161327" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161328" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161330" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161332" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161334" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161336" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161338" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161340" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161342" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161344" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161346" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161348" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161349" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161350" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161351" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161352" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161353" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161354" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161355" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161356" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161357" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161358" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161359" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161360" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161361" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161362" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161363" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161364" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161365" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161366" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161367" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161368" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161369" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161370" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161371" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161372" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161373" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161374" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161375" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161376" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161377" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161378" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161379" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161380" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161381" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161382" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161383" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161384" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161385" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161386" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161387" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161388" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161389" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161390" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161391" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161392" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161393" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161394" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161395" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161396" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161397" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161398" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161399" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161400" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161401" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161402" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161403" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161404" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161405" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161406" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161407" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161408" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161409" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161410" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161411" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161412" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161413" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161414" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161415" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161416" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161417" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161518" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161519" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161520" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161521" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161522" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161523" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161524" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161525" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161526" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161527" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161528" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161529" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161530" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161531" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161532" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161533" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161534" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161535" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161536" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161537" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161538" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161539" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161540" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161541" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161542" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161543" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161544" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161545" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161546" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161547" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161548" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161549" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161550" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161551" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161552" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161553" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161554" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161555" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161556" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161557" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161558" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161559" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161560" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161561" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161562" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161563" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161564" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161565" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161566" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161567" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161568" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161569" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161570" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161571" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161572" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161573" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161574" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161575" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161576" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161577" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161578" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161579" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161580" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161581" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161582" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161583" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161584" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161585" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161586" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161587" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161588" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161589" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161590" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161591" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161592" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161593" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161594" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161595" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161596" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161597" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161598" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161599" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161600" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161601" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161602" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161603" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161604" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161605" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161606" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161607" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161608" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161609" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161610" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161611" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161612" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161613" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161614" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161615" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161616" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161617" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161718" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161719" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161720" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161721" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161722" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161723" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161724" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161725" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161726" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161727" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161728" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161729" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161730" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161731" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161732" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161733" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161734" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161735" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161736" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161737" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161738" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161739" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161740" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161741" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161742" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161743" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161744" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161745" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161746" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161747" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161748" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161749" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161750" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161751" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161752" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161753" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161754" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161755" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161756" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161757" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161758" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161759" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161760" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161761" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161762" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161763" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161764" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161765" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161766" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161767" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161768" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161769" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161770" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161771" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161772" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161774" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161775" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161776" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161777" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161778" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161779" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161780" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161781" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161782" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161783" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161784" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161785" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161786" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161787" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161788" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161789" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161790" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161791" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161792" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161793" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161794" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161795" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161796" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161797" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161798" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161799" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161800" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161801" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161802" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161803" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161804" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161805" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161806" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161807" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161808" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161809" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161810" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161811" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161812" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161813" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161814" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161815" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161816" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161817" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161818" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161218" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161219" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161220" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161221" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161222" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161223" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161224" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161225" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161226" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161227" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161228" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161229" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161230" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161231" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161232" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161233" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161234" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161235" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161236" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161237" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161238" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161239" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161240" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161241" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161242" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161243" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161244" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161245" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161246" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161247" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161248" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161249" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161250" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161251" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161252" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161253" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161254" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161255" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161256" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161257" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161258" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161259" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161260" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161261" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161262" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161263" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161264" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161265" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161266" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161267" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161268" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161269" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161270" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161271" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161272" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161273" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161274" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161275" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161276" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161277" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161278" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161279" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161280" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161281" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161282" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161283" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161284" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161285" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161286" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161287" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161288" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161289" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161290" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161292" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161293" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161294" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161296" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161299" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161301" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161303" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161305" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161307" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161309" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161311" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161313" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161315" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161320" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161322" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161324" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161326" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161329" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161331" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161333" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161335" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161337" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161339" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161341" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161343" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161345" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161347" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161820" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161821" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161822" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161823" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161824" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161825" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161826" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161827" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161828" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161829" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161830" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161831" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161832" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161833" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161834" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161835" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161836" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161837" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161838" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161839" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161840" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161841" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161842" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161843" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161844" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161845" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161846" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161847" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161848" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161849" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161850" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161851" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161852" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161853" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161854" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161855" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161856" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161857" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161858" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161859" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161860" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161861" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161862" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161863" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161864" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161865" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161866" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161867" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161868" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161869" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161870" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161871" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161872" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161873" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161874" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161875" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161876" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161877" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161878" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161879" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161880" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161881" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161882" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161883" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161884" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161885" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161886" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161887" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161888" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161889" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161890" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161891" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161892" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161893" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161894" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161895" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161896" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161897" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161898" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161899" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161900" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161901" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161902" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161903" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161904" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161905" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161906" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161907" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161908" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161909" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161910" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161911" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161912" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161913" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161914" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161915" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161916" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161917" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161918" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161919" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161418" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161419" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161420" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161421" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161422" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161423" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161424" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161425" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161426" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161427" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161428" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161429" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161430" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161431" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161432" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161433" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161434" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161435" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161436" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161437" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161438" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161439" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161440" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161441" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161442" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161443" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161923" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161924" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161925" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161926" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161927" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161928" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161929" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161930" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161931" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161932" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161933" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161934" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161935" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161936" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161937" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161938" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161939" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161940" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161941" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161942" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161943" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161944" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161945" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161946" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161947" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161948" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161949" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161950" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161951" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161952" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161953" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161954" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161955" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161956" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161957" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161958" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161959" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161960" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161961" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161962" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161963" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161670" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161671" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161672" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161673" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161674" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161675" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161676" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161677" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161686" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161687" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161688" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161689" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161690" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161691" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161692" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161693" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161694" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161695" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161696" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161697" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161698" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161699" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161700" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161701" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161702" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161703" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161704" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161705" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161706" servicegroup="baggage" serviceid="FBA_2"></map><map elemtype="legXRef" elemid="225536161218" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161219" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161220" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161221" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161222" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161223" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161224" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161225" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161226" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161227" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161228" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161229" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161230" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161231" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161232" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161233" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161234" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161235" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161236" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161237" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161238" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161239" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161240" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161241" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161242" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161243" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161244" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161245" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161246" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161247" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161248" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161249" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161250" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161251" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161252" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161253" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161254" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161255" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161256" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161257" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161258" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161259" servicegroup="farefamily" serviceid="BF_1"></map><map elemtype="legXRef" elemid="225536161260" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161261" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161262" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161263" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161264" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161265" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161266" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161267" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161268" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161269" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161270" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161271" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161272" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161273" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161274" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161275" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161276" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161277" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161278" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161279" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161280" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161281" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161282" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161283" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161284" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161285" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161286" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161287" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161288" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161289" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161290" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161292" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161293" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161294" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161296" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161299" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161301" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161303" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161305" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161307" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161309" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161311" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161670" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161671" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161672" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161673" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161687" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161688" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161690" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161691" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161693" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161694" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161696" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161697" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161699" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161700" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161702" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161703" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161705" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161706" servicegroup="farefamily" serviceid="BF_2"></map><map elemtype="legXRef" elemid="225536161313" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161315" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161320" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161322" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161324" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161326" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161329" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161331" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161333" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161335" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161337" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161339" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161341" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161343" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161345" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161347" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161418" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161419" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161420" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161421" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161422" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161423" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161424" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161425" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161426" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161427" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161428" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161429" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161430" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161431" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161432" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161433" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161434" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161435" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161436" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161437" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161438" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161439" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161440" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161441" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161442" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161443" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161674" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161675" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161676" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161677" servicegroup="farefamily" serviceid="BF_3"></map><map elemtype="legXRef" elemid="225536161686" servicegroup="farefamily" serviceid="BF_4"></map><map elemtype="legXRef" elemid="225536161689" servicegroup="farefamily" serviceid="BF_4"></map><map elemtype="legXRef" elemid="225536161692" servicegroup="farefamily" serviceid="BF_4"></map><map elemtype="legXRef" elemid="225536161695" servicegroup="farefamily" serviceid="BF_4"></map><map elemtype="legXRef" elemid="225536161698" servicegroup="farefamily" serviceid="BF_4"></map><map elemtype="legXRef" elemid="225536161701" servicegroup="farefamily" serviceid="BF_4"></map><map elemtype="legXRef" elemid="225536161704" servicegroup="farefamily" serviceid="BF_4"></map></servicemappings>
</availresponse>